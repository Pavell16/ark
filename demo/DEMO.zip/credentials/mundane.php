<?php
$username="pavell";
$password="";