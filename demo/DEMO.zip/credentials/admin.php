<?php
$username="root";
$password="";