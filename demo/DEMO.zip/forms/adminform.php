
<div class="card adminform">

    <h1>ADMIN</h1> 
    <form action="index.php" method="post">
                
        <div class="form-group ">
            <h2>Afegir</h2>
            <button type="submit" name="admbtn" value="addsales">SALES</button>
            <button type="submit" name="admbtn" value="addmotius">MOTIUS</button>
            <button type="submit" name="admbtn" value="addusuaris">USUARIS</button>
            <br>
            <h2>Treure</h2>
            <button type="submit" name="admbtn" value="rmsales">SALES</button>
            <button type="submit" name="admbtn" value="rmmotius">MOTIUS</button>
            <button type="submit" name="admbtn" value="rmusuaris">USUARIS</button>
            <br>
            <h2>Mostrar</h2>
            <button type="submit" name="admbtn" value="shsales">SALES</button>
            <button type="submit" name="admbtn" value="shmotius">MOTIUS</button>
            <button type="submit" name="admbtn" value="shusuaris">USUARIS</button>
            <br>
            <h2>Fitxatges</h2>
            <button type="submit" name="admbtn" value="shfitxa">FITXATGE</button>
            <br>
            <h2>Logout</h2>
            <button type="submit" formaction="utilities/logout.php" formmethod="post">LOGOUT</button>
        </div>
    </form>
</div>