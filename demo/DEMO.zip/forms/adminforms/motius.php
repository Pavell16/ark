
<div class="card">

    <h1>Motiu Nou</h1> 
    <form action="sql/insertamotiu.php" method="post">
                
        <div class="form-group">
            <label for="motiu">MOTIU</label>
            <input type="text" id="motiu" name="motiu">
        </div>
            <button type="submit">Afegeix</button>
            <button type="submit" formaction="index.php" formmethod="post" name="admbtn" value="admin">Tornar</button>
    </form>
</div>